WinBlitz3D Version 1.0 
	copyright(2005/2006) Kevin Poole
	kev.poole@ntlworld.com


Hi guys, Well here it is finaly v1.0.

Whats WinBlitz3D?
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	WinBlitz3D is a true windows api .dll that enables window'ed mode Blitz3D to have a fancy windows gui, WinBlitz3D intergates fully along side blitz3d in an easy to master command set. Blitz3D owners that also own BlitzPlus and wanted the power of both GUI and 3D combined can now have what they always desierd.

	 	
WinBlitz3D core features
~~~~~~~~~~~~~~~~~~~~~~~~
	
Full GUI intergration in to Blitz3D, Gadgets can be placed directly within the Blitz3D window. WinBlitz3D also hosts support for complete control of the way you create your gadgets, this enables the most complex gadget creation available. WinBlitz3D event system is based on a (first in / first out) orderd queue, Although the event queue can be manipulated in realtime.   